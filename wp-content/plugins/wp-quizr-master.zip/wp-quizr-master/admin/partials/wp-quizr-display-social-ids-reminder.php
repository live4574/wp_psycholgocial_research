
<div class="inside">
    
    <p class="metabox-p"><?php esc_html_e('Don\'t forget to provide at least one social network to which you would like users to share their quiz results. Go to WP Quizr Settings to do this.', 'wp-quizr'); ?></p>

</div>

