    <meta name="fbAppId" content="<?php echo esc_attr($wp_quizr_options['option_fb_id']); ?>">

    <meta name="twtr_handle" content="<?php echo esc_attr($wp_quizr_options['option_twtr_handle']); ?>">

    <meta name="image_url" content="">

    <meta name="outcome_title" content="">

    <meta name="outcome_description" content="">

    <meta name="shareUrl" content="<?php echo rawurlencode(get_post_permalink()); ?>">