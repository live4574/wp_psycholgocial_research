#WordPress Simple Location Plugin#

This plugin defines a simple location custom content type that an administrator can use to create locations for their stores / businesses.

Upload the 'wp_simple_location_plugin' files directly to your plugins directory and activate (alternatively you can zip the folder and upload it via WordPress's plugin upload) 

For a more thorough description on how this work, please feel free to visit my related SitePoint article 
